export { default } from './Logo'
