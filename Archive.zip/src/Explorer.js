import React from 'react'
import './Explorer.css'
import Router from './Router'

class Explorer extends React.Component {
  render() {
    return (
      <div>
        <Router />
      </div>
    )
  }
}

export default Explorer
