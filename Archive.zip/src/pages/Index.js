import React, { Component } from 'react'
import { Content } from '../components/AppLayout'
import ReactMapboxGl, { GeoJSONLayer, Marker, Feature } from 'react-mapbox-gl'
import { readRemoteFile, readString } from 'react-papaparse'
import clusters from '../data/clusters.json'
import geoJSON from 'geojson'
import geojson2h3 from 'geojson2h3'
import {h3ToGeo} from "h3-js";

const Mapbox = ReactMapboxGl({
  accessToken:
    'pk.eyJ1IjoicGV0ZXJtYWluIiwiYSI6ImNqMHA5dm8xbTAwMGQycXMwa3NucGptenQifQ.iVCDWzb16acgOKWz65AckA',
})

const redCircle = {
  'circle-color': '#CA0926',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const greenCircle = {
  'circle-color': '#09B851',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const yellowCircle = {
  'circle-color': '#F1C40F',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const blueCircle = {
  'circle-color': '#0521EB',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const cyanCircle = {
  'circle-color': '#00FFFF',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const whiteCircle = {
  'circle-color': '#FFFFFF',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const orangeCircle = {
  'circle-color': '#FFA500',
  'circle-radius': 5,
  'circle-opacity': 1,
  'circle-blur': 0,
}

const hexFill = {
  'fill-color': '#00FFFF',
  'fill-opacity': 1
}

const hexBoundingLine = {
  "line-width": 1,
  "line-color": "#00a0ff",
  "line-opacity": 0.8
}

class Index extends Component {
  state = {
    green: [],
    red: [],
    blue: [],
    yellow: [],
    cyan: [],
    white: [],
    orange: [],
    hexes: [],
    hexBounding: false,
    showRed: true,
    showYellow: true,
    showBlue: true,
    showGreen: true,
    showCyan: true,
    name: '',
    vals: [],
    zoom: [12],
    center: [-122.39172223773895, 37.783584171422625],
  }

  toggleYellow = this.toggleYellow.bind(this)

  async componentDidMount() {
    /*const tempHexes = []
    console.log(clusters)
    clusters.map((c) => {
      tempHexes.push(c.index)
    })
    const geohexes = geojson2h3.h3SetToFeatureCollection(tempHexes, hex => ({clusters: clusters.find(e => e.index === hex).clusters}))*/
    var self = this
    let greens = []
    let reds = []
    let blues = []
    let yellows = []
    let cyans = []
    let whites = []
    let oranges = []
    readRemoteFile(
      '/scale_8.csv',
      {
        header: true,
        download: true,
        dynamicTyping: true,
        complete: function (res) {
          res.data.map((r) => {
            let obj = {
              lat: r.latitude,
              lon: r.longitude,
              name: r.name,
              vals: r.desc
                ? JSON.stringify(r.desc.split('|'))
                : ['no data', 'no data', 'no data', 'no data'],
            }
            if (r.color == 'red') {
              reds.push(obj)
            } else if (r.color == 'green') {
              greens.push(obj)
            } else if (r.color == 'yellow') {
              yellows.push(obj)
            } else if (r.color == 'blue') {
              blues.push(obj)
            } else if (r.color == 'cyan') {
              cyans.push(obj)
            } else if (r.color == 'white') {
              whites.push(obj)
            } else if (r.color == 'orange') {
              oranges.push(obj)
            }
          })
          self.setState({
            green: geoJSON.parse(greens, { Point: ['lat', 'lon'] }),
            red: geoJSON.parse(reds, { Point: ['lat', 'lon'] }),
            blue: geoJSON.parse(blues, { Point: ['lat', 'lon'] }),
            yellow: geoJSON.parse(yellows, { Point: ['lat', 'lon'] }),
            cyan: geoJSON.parse(cyans, { Point: ['lat', 'lon'] }),
            white: geoJSON.parse(whites, { Point: ['lat', 'lon'] }),
            orange: geoJSON.parse(oranges, { Point: ['lat', 'lon'] }),
          })
        },
      },
    )
  }

  toggleYellow() {
    console.log('toggling')
    this.setState((prevState) => ({
      showYellow: !prevState.showYellow,
    }))
  }

  updateBox(e) {
    this.setState({
      name: e.features[0].properties.name,
      vals: JSON.parse(e.features[0].properties.vals),
    })
  }

  captureMove(e) {
    const [hexFeatures, pointFeatures] = this.getFeatures(e.getBounds());
    this.setState({
      zoom: [e.getZoom()],
      center: [e.getCenter().lng, e.getCenter().lat],
      hexBounding: hexFeatures
    })
  }

  getFeatures(bbox) {
    console.log(bbox)
    const bboxFeature = ({
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [bbox._sw.lng, bbox._sw.lat],
          [bbox._sw.lng, bbox._ne.lat],
          [bbox._ne.lng, bbox._ne.lat],
          [bbox._ne.lng, bbox._sw.lat],
          [bbox._sw.lng, bbox._sw.lat]
        ]]
      }
    });
  
    const hexagons = geojson2h3.featureToH3Set(bboxFeature, 8);
    console.log(hexagons)
  
    const hexPolygon = geojson2h3.h3SetToMultiPolygonFeature(hexagons);
    const points = {
      "type": "FeatureCollection",
      "features": hexagons.map(hex => (
        {
          "type": "Feature",
          "properties": {
            "hex": hex
          },
          "geometry": {
            "type": "Point",
            "coordinates": h3ToGeo(hex).reverse()
          }
        }
      ))
    }
    console.log(hexPolygon)
    return [hexPolygon, points];
  }

  loadInitial(e) {
    const [hexFeatures, pointFeatures] = this.getFeatures(e.getBounds());
    this.setState({hexBounding: hexFeatures})
  }

  render() {
    const {
      red,
      blue,
      green,
      yellow,
      cyan,
      white,
      orange,
      name,
      vals,
      zoom,
      center,
      showBlue,
      showCyan,
      showGreen,
      showRed,
      showYellow,
      hexes,
      hexBounding
    } = this.state

    return (
      <Content>
        <Mapbox
          style="mapbox://styles/mapbox/dark-v10"
          container="map"
          center={center}
          containerStyle={{
            position: 'relative',
            width: '100%',
            height: '100vh',
            overflow: 'visible',
          }}
          zoom={zoom}
          movingMethod="jumpTo"
          onMoveEnd={(e) => this.captureMove(e)}
          onStyleLoad={(e) => this.loadInitial(e)}
        >          
          {/*<GeoJSONLayer
            id="hexes"
            data={hexes}
            fillPaint={hexFill}
          />*/}
          <GeoJSONLayer
            id="hexBounding"
            data={hexBounding}
            linePaint={hexBoundingLine}
          />
          <GeoJSONLayer
            id="red"
            data={red}
            circlePaint={redCircle}
          />
          <GeoJSONLayer
            id="yellow"
            data={yellow}
            circlePaint={yellowCircle}
          />
          <GeoJSONLayer
            id="green"
            data={green}
            circlePaint={greenCircle}
          />
          <GeoJSONLayer
            id="orange"
            data={orange}
            circlePaint={orangeCircle}
          />
          <GeoJSONLayer
            id="cyan"
            data={cyan}
            circlePaint={cyanCircle}
          />
          
          <div
            style={{
              width: '160px',
              height: '140px',
              backgroundColor: 'white',
              position: 'absolute',
              bottom: '30px',
              right: '30px',
              padding: '20px',
            }}
          >
            <div
              style={{
                background: '#09B851',
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                float: 'left',
                marginRight: '5px',
                marginTop: '5px',
              }}
            ></div>
            <span> 1.0 ({green.features && green.features.length})</span>
          
          <br />
            <div
              style={{
                background: '#00FFFF',
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                float: 'left',
                marginRight: '5px',
                marginTop: '5px',
              }}
            ></div>
            <span> 0.8 ({cyan.features && cyan.features.length})</span>
            <br />
            <div
              style={{
                background: '#F1C40F',
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                float: 'left',
                marginRight: '5px',
                marginTop: '5px',
              }}
            ></div>
            <span> 0.5 ({yellow.features && yellow.features.length})</span>
            <br />
            <div
              style={{
                background: '#FFA500',
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                float: 'left',
                marginRight: '5px',
                marginTop: '5px',
              }}
            ></div>
            <span>
              {' '}
              0.3 ({orange.features && orange.features.length})
            </span>
            <br />
            <div
              style={{
                background: '#CA0926',
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                float: 'left',
                marginRight: '5px',
                marginTop: '5px',
              }}
            ></div>
            <span> 0.1 ({red.features && red.features.length})</span>
          </div>

            
        </Mapbox>
      </Content>
    )
  }
}

export default Index
